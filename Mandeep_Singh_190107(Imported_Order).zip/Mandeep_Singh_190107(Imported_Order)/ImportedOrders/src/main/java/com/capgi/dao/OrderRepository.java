package com.capgi.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.capgi.bean.Order;
@Repository
public class OrderRepository implements DAOInterface{
    
	@Autowired
	OrderRepositoryInterface repo;
	//Adding Order 
	@Override
	public Order addOrders(Order order) {
		
		return repo.save(order);
	}
//Getting all Details of Order
	public List<Order> getAllOrders() {
		
		return repo.findAll();
	}
//Update Order
	@Override
	public Order updateOrder(Order order) {
		
		return repo.save(order);
	}
//Getting Orders by Quantity Range
	@Override
	public List<Order> findByQuantity(int quantity1, int quantity2) {
		
		return repo.findByRange(quantity1,quantity2);
	}
//Getting Orders BY greater than ammount
	@Override
	public List<Order> greaterByAmount(double amount) {
		
		return repo.findBygreater(amount);
	}

}
