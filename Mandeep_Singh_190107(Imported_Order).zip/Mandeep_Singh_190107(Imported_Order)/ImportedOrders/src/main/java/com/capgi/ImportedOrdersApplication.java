package com.capgi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImportedOrdersApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImportedOrdersApplication.class, args);
	}

}
