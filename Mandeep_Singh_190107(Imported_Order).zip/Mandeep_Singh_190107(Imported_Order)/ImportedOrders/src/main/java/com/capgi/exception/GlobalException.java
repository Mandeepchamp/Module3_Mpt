package com.capgi.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capgi.ErrorInformation;
//GlobalException


@ControllerAdvice
public class GlobalException extends Exception{

	 @ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Employee Not Found")
	 @ExceptionHandler({GlobalException.class})
 public ErrorInformation globalHandling(Exception ex,HttpServletRequest request) {	
	String message = ex.getMessage();
    String uri = request.getRequestURL().toString();
	return new ErrorInformation(uri,message);
 }
 
 
 }
